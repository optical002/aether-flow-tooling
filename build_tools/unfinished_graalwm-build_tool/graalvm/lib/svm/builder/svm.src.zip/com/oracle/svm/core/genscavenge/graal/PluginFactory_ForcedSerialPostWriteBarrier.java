// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: jdk.graal.compiler.replacements.processor.ReplacementsAnnotationProcessor, jdk.graal.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.genscavenge.graal;


import java.lang.annotation.Annotation;
import jdk.graal.compiler.core.common.type.Stamp;
import jdk.graal.compiler.graph.NodeInputList;
import jdk.graal.compiler.nodes.PluginReplacementNode;
import jdk.graal.compiler.nodes.ValueNode;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import jdk.graal.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugins;
import jdk.graal.compiler.nodes.spi.Replacements;
import jdk.graal.compiler.options.ExcludeFromJacocoGeneratedReport;
import jdk.vm.ci.meta.ResolvedJavaMethod;

//        class: com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier
//       method: force(jdk.graal.compiler.nodes.memory.address.AddressNode.Address,boolean)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_ForcedSerialPostWriteBarrier_force extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        boolean arg1;
        if (args[1].isConstant()) {
            arg1 = args[1].asJavaConstant().asInt() != 0;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_ForcedSerialPostWriteBarrier_force.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[1];
            return false;
        }
        com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier node = new com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier(arg0, arg1);
        b.add(node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_ForcedSerialPostWriteBarrier_force() {
        super("force", jdk.graal.compiler.nodes.memory.address.AddressNode.Address.class, boolean.class);
    }
}
//        class: com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier
//       method: force(jdk.graal.compiler.nodes.memory.address.AddressNode.Address,boolean)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_ForcedSerialPostWriteBarrier_force implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_ForcedSerialPostWriteBarrier_force();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        ValueNode arg0 = args.get(0);
        boolean arg1;
        if (args.get(1).isConstant()) {
            arg1 = args.get(1).asJavaConstant().asInt() != 0;
        } else {
            return false;
        }
        com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier node = new com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier(arg0, arg1);
        b.add(node);
        return true;
    }
}

public class PluginFactory_ForcedSerialPostWriteBarrier implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier.class, new Plugin_ForcedSerialPostWriteBarrier_force());
    }
}
