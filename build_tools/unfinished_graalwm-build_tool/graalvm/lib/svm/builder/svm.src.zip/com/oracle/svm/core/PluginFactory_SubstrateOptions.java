// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: jdk.graal.compiler.replacements.processor.ReplacementsAnnotationProcessor, jdk.graal.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core;


import java.lang.annotation.Annotation;
import jdk.graal.compiler.core.common.type.Stamp;
import jdk.graal.compiler.graph.NodeInputList;
import jdk.graal.compiler.nodes.ConstantNode;
import jdk.graal.compiler.nodes.PluginReplacementNode;
import jdk.graal.compiler.nodes.ValueNode;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedFoldInvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import jdk.graal.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugins;
import jdk.graal.compiler.nodes.spi.Replacements;
import jdk.graal.compiler.options.ExcludeFromJacocoGeneratedReport;
import jdk.vm.ci.meta.JavaConstant;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;

//        class: com.oracle.svm.core.SubstrateOptions
//       method: codeAlignment()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_codeAlignment extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_codeAlignment.FUNCTION);
            return true;
        }
        int result = com.oracle.svm.core.SubstrateOptions.codeAlignment();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_codeAlignment() {
        super("codeAlignment");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: codeAlignment()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_codeAlignment implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_codeAlignment();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        int result = com.oracle.svm.core.SubstrateOptions.codeAlignment();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: getAllocatePrefetchStyle()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_getAllocatePrefetchStyle extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_getAllocatePrefetchStyle.FUNCTION);
            return true;
        }
        int result = com.oracle.svm.core.SubstrateOptions.getAllocatePrefetchStyle();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_getAllocatePrefetchStyle() {
        super("getAllocatePrefetchStyle");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: getAllocatePrefetchStyle()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_getAllocatePrefetchStyle implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_getAllocatePrefetchStyle();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        int result = com.oracle.svm.core.SubstrateOptions.getAllocatePrefetchStyle();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: getImageBuildID()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_getImageBuildID extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_getImageBuildID.FUNCTION);
            return true;
        }
        java.util.UUID result = com.oracle.svm.core.SubstrateOptions.getImageBuildID();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_SubstrateOptions_getImageBuildID(GeneratedPluginInjectionProvider injection) {
        super("getImageBuildID");
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: getImageBuildID()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_getImageBuildID implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_getImageBuildID();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        java.util.UUID result = com.oracle.svm.core.SubstrateOptions.getImageBuildID();
        JavaConstant constant = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: getPageSize()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_getPageSize extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_getPageSize.FUNCTION);
            return true;
        }
        int result = com.oracle.svm.core.SubstrateOptions.getPageSize();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_getPageSize() {
        super("getPageSize");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: getPageSize()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_getPageSize implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_getPageSize();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        int result = com.oracle.svm.core.SubstrateOptions.getPageSize();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: getSourceLevelDebug()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_getSourceLevelDebug extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_getSourceLevelDebug.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.getSourceLevelDebug();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_getSourceLevelDebug() {
        super("getSourceLevelDebug");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: getSourceLevelDebug()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_getSourceLevelDebug implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_getSourceLevelDebug();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.getSourceLevelDebug();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: getSourceLevelDebugFilter()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_getSourceLevelDebugFilter extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_getSourceLevelDebugFilter.FUNCTION);
            return true;
        }
        @SuppressWarnings({"rawtypes"})
        java.util.function.Predicate result = com.oracle.svm.core.SubstrateOptions.getSourceLevelDebugFilter();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_SubstrateOptions_getSourceLevelDebugFilter(GeneratedPluginInjectionProvider injection) {
        super("getSourceLevelDebugFilter");
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: getSourceLevelDebugFilter()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_getSourceLevelDebugFilter implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_getSourceLevelDebugFilter();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        @SuppressWarnings({"rawtypes"})
        java.util.function.Predicate result = com.oracle.svm.core.SubstrateOptions.getSourceLevelDebugFilter();
        JavaConstant constant = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: hasFramePointer()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_hasFramePointer extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_hasFramePointer.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.hasFramePointer();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_hasFramePointer() {
        super("hasFramePointer");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: hasFramePointer()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_hasFramePointer implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_hasFramePointer();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.hasFramePointer();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: isMaximumOptimizationLevel()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_isMaximumOptimizationLevel extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_isMaximumOptimizationLevel.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.isMaximumOptimizationLevel();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_isMaximumOptimizationLevel() {
        super("isMaximumOptimizationLevel");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: isMaximumOptimizationLevel()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_isMaximumOptimizationLevel implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_isMaximumOptimizationLevel();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.isMaximumOptimizationLevel();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: needsExitHandlers()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_needsExitHandlers extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_needsExitHandlers.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.needsExitHandlers();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_needsExitHandlers() {
        super("needsExitHandlers");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: needsExitHandlers()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_needsExitHandlers implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_needsExitHandlers();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.needsExitHandlers();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: optimizationLevel()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_optimizationLevel extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_optimizationLevel.FUNCTION);
            return true;
        }
        com.oracle.svm.core.SubstrateOptions.OptimizationLevel result = com.oracle.svm.core.SubstrateOptions.optimizationLevel();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_SubstrateOptions_optimizationLevel(GeneratedPluginInjectionProvider injection) {
        super("optimizationLevel");
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: optimizationLevel()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_optimizationLevel implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_optimizationLevel();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        com.oracle.svm.core.SubstrateOptions.OptimizationLevel result = com.oracle.svm.core.SubstrateOptions.optimizationLevel();
        JavaConstant constant = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: supportCompileInIsolates()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_supportCompileInIsolates extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_supportCompileInIsolates.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.supportCompileInIsolates();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_supportCompileInIsolates() {
        super("supportCompileInIsolates");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: supportCompileInIsolates()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_supportCompileInIsolates implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_supportCompileInIsolates();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.supportCompileInIsolates();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: useClosedTypeWorld()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_useClosedTypeWorld extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_useClosedTypeWorld.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.useClosedTypeWorld();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_useClosedTypeWorld() {
        super("useClosedTypeWorld");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: useClosedTypeWorld()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_useClosedTypeWorld implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_useClosedTypeWorld();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.useClosedTypeWorld();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: useClosedTypeWorldHubLayout()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_useClosedTypeWorldHubLayout extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_useClosedTypeWorldHubLayout.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.useClosedTypeWorldHubLayout();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_useClosedTypeWorldHubLayout() {
        super("useClosedTypeWorldHubLayout");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: useClosedTypeWorldHubLayout()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_useClosedTypeWorldHubLayout implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_useClosedTypeWorldHubLayout();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.useClosedTypeWorldHubLayout();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: useCodeSizeCompilerConfig()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_useCodeSizeCompilerConfig extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_useCodeSizeCompilerConfig.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.useCodeSizeCompilerConfig();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_useCodeSizeCompilerConfig() {
        super("useCodeSizeCompilerConfig");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: useCodeSizeCompilerConfig()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_useCodeSizeCompilerConfig implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_useCodeSizeCompilerConfig();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.useCodeSizeCompilerConfig();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: useEconomyCompilerConfig()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_useEconomyCompilerConfig extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_useEconomyCompilerConfig.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.useEconomyCompilerConfig();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_useEconomyCompilerConfig() {
        super("useEconomyCompilerConfig");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: useEconomyCompilerConfig()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_useEconomyCompilerConfig implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_useEconomyCompilerConfig();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.useEconomyCompilerConfig();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: useEpsilonGC()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_useEpsilonGC extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_useEpsilonGC.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.useEpsilonGC();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_useEpsilonGC() {
        super("useEpsilonGC");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: useEpsilonGC()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_useEpsilonGC implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_useEpsilonGC();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.useEpsilonGC();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: useG1GC()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_useG1GC extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_useG1GC.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.useG1GC();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_useG1GC() {
        super("useG1GC");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: useG1GC()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_useG1GC implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_useG1GC();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.useG1GC();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: useLIRBackend()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_useLIRBackend extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_useLIRBackend.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.useLIRBackend();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_useLIRBackend() {
        super("useLIRBackend");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: useLIRBackend()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_useLIRBackend implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_useLIRBackend();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.useLIRBackend();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: useLLVMBackend()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_useLLVMBackend extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_useLLVMBackend.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.useLLVMBackend();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_useLLVMBackend() {
        super("useLLVMBackend");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: useLLVMBackend()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_useLLVMBackend implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_useLLVMBackend();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.useLLVMBackend();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: useSerialGC()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_useSerialGC extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_useSerialGC.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.useSerialGC();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_useSerialGC() {
        super("useSerialGC");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: useSerialGC()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_useSerialGC implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_useSerialGC();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.useSerialGC();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

public class PluginFactory_SubstrateOptions implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_codeAlignment());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_getAllocatePrefetchStyle());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_getImageBuildID(injection));
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_getPageSize());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_getSourceLevelDebug());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_getSourceLevelDebugFilter(injection));
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_hasFramePointer());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_isMaximumOptimizationLevel());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_needsExitHandlers());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_optimizationLevel(injection));
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_supportCompileInIsolates());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_useClosedTypeWorld());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_useClosedTypeWorldHubLayout());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_useCodeSizeCompilerConfig());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_useEconomyCompilerConfig());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_useEpsilonGC());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_useG1GC());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_useLIRBackend());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_useLLVMBackend());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_useSerialGC());
    }
}
