// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: jdk.graal.compiler.replacements.processor.ReplacementsAnnotationProcessor, jdk.graal.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.genscavenge.graal;


import java.lang.annotation.Annotation;
import jdk.graal.compiler.core.common.type.Stamp;
import jdk.graal.compiler.debug.GraalError;
import jdk.graal.compiler.graph.NodeInputList;
import jdk.graal.compiler.nodes.PluginReplacementNode;
import jdk.graal.compiler.nodes.ValueNode;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import jdk.graal.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugins;
import jdk.graal.compiler.nodes.spi.Replacements;
import jdk.graal.compiler.options.ExcludeFromJacocoGeneratedReport;
import jdk.vm.ci.meta.ResolvedJavaMethod;

//        class: com.oracle.svm.core.genscavenge.graal.BarrierSnippets
//       method: callPostWriteBarrierStub(jdk.graal.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Object)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_BarrierSnippets_callPostWriteBarrierStub extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        jdk.graal.compiler.core.common.type.Stamp arg0 = stamp;
        jdk.graal.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(jdk.graal.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_BarrierSnippets_callPostWriteBarrierStub.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (jdk.graal.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_BarrierSnippets_callPostWriteBarrierStub.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final jdk.graal.compiler.core.common.type.Stamp stamp;
    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_BarrierSnippets_callPostWriteBarrierStub(GeneratedPluginInjectionProvider injection) {
        super("callPostWriteBarrierStub", jdk.graal.compiler.core.common.spi.ForeignCallDescriptor.class, java.lang.Object.class);
        this.stamp = injection.getInjectedStamp(void.class);
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.genscavenge.graal.BarrierSnippets
//       method: callPostWriteBarrierStub(jdk.graal.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Object)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_BarrierSnippets_callPostWriteBarrierStub implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_BarrierSnippets_callPostWriteBarrierStub();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        jdk.graal.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(void.class);
        jdk.graal.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(jdk.graal.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (jdk.graal.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

public class PluginFactory_BarrierSnippets implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.genscavenge.graal.BarrierSnippets.class, new Plugin_BarrierSnippets_callPostWriteBarrierStub(injection));
    }
}
