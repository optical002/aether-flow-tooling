// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: jdk.graal.compiler.replacements.processor.ReplacementsAnnotationProcessor, jdk.graal.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.genscavenge;


import java.lang.annotation.Annotation;
import jdk.graal.compiler.core.common.type.Stamp;
import jdk.graal.compiler.graph.NodeInputList;
import jdk.graal.compiler.nodes.ConstantNode;
import jdk.graal.compiler.nodes.PluginReplacementNode;
import jdk.graal.compiler.nodes.ValueNode;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedFoldInvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import jdk.graal.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugins;
import jdk.graal.compiler.nodes.spi.Replacements;
import jdk.graal.compiler.options.ExcludeFromJacocoGeneratedReport;
import jdk.vm.ci.meta.JavaConstant;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;

//        class: com.oracle.svm.core.genscavenge.HeapParameters
//       method: getAlignedHeapChunkAlignment()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_HeapParameters_getAlignedHeapChunkAlignment extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_HeapParameters_getAlignedHeapChunkAlignment.FUNCTION);
            return true;
        }
        org.graalvm.word.UnsignedWord result = com.oracle.svm.core.genscavenge.HeapParameters.getAlignedHeapChunkAlignment();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_HeapParameters_getAlignedHeapChunkAlignment(GeneratedPluginInjectionProvider injection) {
        super("getAlignedHeapChunkAlignment");
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.genscavenge.HeapParameters
//       method: getAlignedHeapChunkAlignment()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_HeapParameters_getAlignedHeapChunkAlignment implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_HeapParameters_getAlignedHeapChunkAlignment();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.word.UnsignedWord result = com.oracle.svm.core.genscavenge.HeapParameters.getAlignedHeapChunkAlignment();
        JavaConstant constant = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.genscavenge.HeapParameters
//       method: getAlignedHeapChunkSize()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_HeapParameters_getAlignedHeapChunkSize extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_HeapParameters_getAlignedHeapChunkSize.FUNCTION);
            return true;
        }
        org.graalvm.word.UnsignedWord result = com.oracle.svm.core.genscavenge.HeapParameters.getAlignedHeapChunkSize();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_HeapParameters_getAlignedHeapChunkSize(GeneratedPluginInjectionProvider injection) {
        super("getAlignedHeapChunkSize");
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.genscavenge.HeapParameters
//       method: getAlignedHeapChunkSize()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_HeapParameters_getAlignedHeapChunkSize implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_HeapParameters_getAlignedHeapChunkSize();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.word.UnsignedWord result = com.oracle.svm.core.genscavenge.HeapParameters.getAlignedHeapChunkSize();
        JavaConstant constant = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.genscavenge.HeapParameters
//       method: getLargeArrayThreshold()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_HeapParameters_getLargeArrayThreshold extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_HeapParameters_getLargeArrayThreshold.FUNCTION);
            return true;
        }
        org.graalvm.word.UnsignedWord result = com.oracle.svm.core.genscavenge.HeapParameters.getLargeArrayThreshold();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_HeapParameters_getLargeArrayThreshold(GeneratedPluginInjectionProvider injection) {
        super("getLargeArrayThreshold");
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.genscavenge.HeapParameters
//       method: getLargeArrayThreshold()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_HeapParameters_getLargeArrayThreshold implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_HeapParameters_getLargeArrayThreshold();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.word.UnsignedWord result = com.oracle.svm.core.genscavenge.HeapParameters.getLargeArrayThreshold();
        JavaConstant constant = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.genscavenge.HeapParameters
//       method: getMaxSurvivorSpaces()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_HeapParameters_getMaxSurvivorSpaces extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_HeapParameters_getMaxSurvivorSpaces.FUNCTION);
            return true;
        }
        int result = com.oracle.svm.core.genscavenge.HeapParameters.getMaxSurvivorSpaces();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_HeapParameters_getMaxSurvivorSpaces() {
        super("getMaxSurvivorSpaces");
    }
}
//        class: com.oracle.svm.core.genscavenge.HeapParameters
//       method: getMaxSurvivorSpaces()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_HeapParameters_getMaxSurvivorSpaces implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_HeapParameters_getMaxSurvivorSpaces();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        int result = com.oracle.svm.core.genscavenge.HeapParameters.getMaxSurvivorSpaces();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.genscavenge.HeapParameters
//       method: getMinUnalignedChunkSize()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_HeapParameters_getMinUnalignedChunkSize extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_HeapParameters_getMinUnalignedChunkSize.FUNCTION);
            return true;
        }
        org.graalvm.word.UnsignedWord result = com.oracle.svm.core.genscavenge.HeapParameters.getMinUnalignedChunkSize();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_HeapParameters_getMinUnalignedChunkSize(GeneratedPluginInjectionProvider injection) {
        super("getMinUnalignedChunkSize");
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.genscavenge.HeapParameters
//       method: getMinUnalignedChunkSize()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_HeapParameters_getMinUnalignedChunkSize implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_HeapParameters_getMinUnalignedChunkSize();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.word.UnsignedWord result = com.oracle.svm.core.genscavenge.HeapParameters.getMinUnalignedChunkSize();
        JavaConstant constant = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

public class PluginFactory_HeapParameters implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.genscavenge.HeapParameters.class, new Plugin_HeapParameters_getAlignedHeapChunkAlignment(injection));
        plugins.register(com.oracle.svm.core.genscavenge.HeapParameters.class, new Plugin_HeapParameters_getAlignedHeapChunkSize(injection));
        plugins.register(com.oracle.svm.core.genscavenge.HeapParameters.class, new Plugin_HeapParameters_getLargeArrayThreshold(injection));
        plugins.register(com.oracle.svm.core.genscavenge.HeapParameters.class, new Plugin_HeapParameters_getMaxSurvivorSpaces());
        plugins.register(com.oracle.svm.core.genscavenge.HeapParameters.class, new Plugin_HeapParameters_getMinUnalignedChunkSize(injection));
    }
}
