// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: CodeInfoDecoder.java
package com.oracle.svm.core.code;

import java.util.*;
import jdk.graal.compiler.options.*;
import jdk.graal.compiler.options.OptionType;
import jdk.graal.compiler.options.OptionStability;

public class CodeInfoDecoder_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "CodeInfoIndexGranularity": {
            return OptionDescriptor.create(
                /*name*/ "CodeInfoIndexGranularity",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Integer.class,
                /*help*/ "The granularity of the index for looking up code metadata. Should be a power of 2. Larger values make the index smaller, but access slower.",
                /*declaringClass*/ CodeInfoDecoder.Options.class,
                /*fieldName*/ "CodeInfoIndexGranularity",
                /*option*/ CodeInfoDecoder.Options.CodeInfoIndexGranularity,
                /*stability*/ OptionStability.EXPERIMENTAL,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 1;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("CodeInfoIndexGranularity");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
