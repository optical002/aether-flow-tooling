// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: SubstrateDiagnostics.java
package com.oracle.svm.core;

import java.util.*;
import jdk.graal.compiler.options.*;
import jdk.graal.compiler.options.OptionType;
import jdk.graal.compiler.options.OptionStability;

public class SubstrateDiagnostics_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "ImplicitExceptionWithoutStacktraceIsFatal": {
            return OptionDescriptor.create(
                /*name*/ "ImplicitExceptionWithoutStacktraceIsFatal",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Determines if implicit exceptions are fatal if they don't have a stack trace.",
                /*declaringClass*/ SubstrateDiagnostics.Options.class,
                /*fieldName*/ "ImplicitExceptionWithoutStacktraceIsFatal",
                /*option*/ SubstrateDiagnostics.Options.ImplicitExceptionWithoutStacktraceIsFatal,
                /*stability*/ OptionStability.EXPERIMENTAL,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "LoopOnFatalError": {
            return OptionDescriptor.create(
                /*name*/ "LoopOnFatalError",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Execute an endless loop before printing diagnostics for a fatal error.",
                /*declaringClass*/ SubstrateDiagnostics.Options.class,
                /*fieldName*/ "LoopOnFatalError",
                /*option*/ SubstrateDiagnostics.Options.LoopOnFatalError,
                /*stability*/ OptionStability.EXPERIMENTAL,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 2;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("ImplicitExceptionWithoutStacktraceIsFatal");
                    case 1: return get("LoopOnFatalError");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
