// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: jdk.graal.compiler.replacements.processor.ReplacementsAnnotationProcessor, jdk.graal.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.dcmd;


import java.lang.annotation.Annotation;
import jdk.graal.compiler.core.common.type.Stamp;
import jdk.graal.compiler.graph.NodeInputList;
import jdk.graal.compiler.nodes.ConstantNode;
import jdk.graal.compiler.nodes.PluginReplacementNode;
import jdk.graal.compiler.nodes.ValueNode;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedFoldInvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import jdk.graal.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugins;
import jdk.graal.compiler.nodes.spi.Replacements;
import jdk.graal.compiler.options.ExcludeFromJacocoGeneratedReport;
import jdk.vm.ci.meta.JavaConstant;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;

//        class: com.oracle.svm.core.dcmd.DCmdSupport
//       method: singleton()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_DCmdSupport_singleton extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_DCmdSupport_singleton.FUNCTION);
            return true;
        }
        com.oracle.svm.core.dcmd.DCmdSupport result = com.oracle.svm.core.dcmd.DCmdSupport.singleton();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_DCmdSupport_singleton(GeneratedPluginInjectionProvider injection) {
        super("singleton");
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.dcmd.DCmdSupport
//       method: singleton()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_DCmdSupport_singleton implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_DCmdSupport_singleton();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        com.oracle.svm.core.dcmd.DCmdSupport result = com.oracle.svm.core.dcmd.DCmdSupport.singleton();
        JavaConstant constant = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

public class PluginFactory_DCmdSupport implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.dcmd.DCmdSupport.class, new Plugin_DCmdSupport_singleton(injection));
    }
}
