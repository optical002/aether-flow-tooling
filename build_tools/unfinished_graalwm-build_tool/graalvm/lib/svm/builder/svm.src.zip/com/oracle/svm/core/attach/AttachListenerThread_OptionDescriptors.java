// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: AttachListenerThread.java
package com.oracle.svm.core.attach;

import java.util.*;
import jdk.graal.compiler.options.*;
import jdk.graal.compiler.options.OptionType;
import jdk.graal.compiler.options.OptionStability;

public class AttachListenerThread_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "JCmdExceptionStackTrace": {
            return OptionDescriptor.create(
                /*name*/ "JCmdExceptionStackTrace",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Determines if stack traces are shown if exceptions occur in diagnostic commands that were triggered via jcmd.",
                /*declaringClass*/ AttachListenerThread.Options.class,
                /*fieldName*/ "JCmdExceptionStackTrace",
                /*option*/ AttachListenerThread.Options.JCmdExceptionStackTrace,
                /*stability*/ OptionStability.EXPERIMENTAL,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 1;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("JCmdExceptionStackTrace");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
