// CheckStyle: stop header check
// CheckStyle: stop line length check
package com.oracle.svm.core.code;

// GENERATED CONTENT - DO NOT EDIT
// Annotated type: com.oracle.svm.core.code.RuntimeMetadataDecoderImpl.MetadataAccessorImpl
// Annotation: com.oracle.svm.core.feature.AutomaticallyRegisteredImageSingleton
// Annotation processor: com.oracle.svm.processor.AutomaticallyRegisteredImageSingletonProcessor

import org.graalvm.nativeimage.ImageSingletons;
import com.oracle.svm.core.feature.AutomaticallyRegisteredFeature;
import org.graalvm.nativeimage.Platforms;

@Platforms({org.graalvm.nativeimage.impl.InternalPlatform.NATIVE_ONLY.class})
@AutomaticallyRegisteredFeature
public class RuntimeMetadataDecoderImplMetadataAccessorImplFeature implements com.oracle.svm.core.feature.InternalFeature, com.oracle.svm.core.layeredimagesingleton.FeatureSingleton, com.oracle.svm.core.layeredimagesingleton.UnsavedSingleton {
    @Override
    public void afterRegistration(AfterRegistrationAccess access) {
        boolean match = false;
        match = match || !ImageSingletons.lookup(com.oracle.svm.core.layeredimagesingleton.LoadedLayeredImageSingletonInfo.class).handledDuringLoading(com.oracle.svm.core.reflect.RuntimeMetadataDecoder.MetadataAccessor.class);
        if (!match) { return; }
        var singleton = new com.oracle.svm.core.code.RuntimeMetadataDecoderImpl.MetadataAccessorImpl();
        if (!ImageSingletons.lookup(com.oracle.svm.core.layeredimagesingleton.LoadedLayeredImageSingletonInfo.class).handledDuringLoading(com.oracle.svm.core.reflect.RuntimeMetadataDecoder.MetadataAccessor.class)){
            ImageSingletons.add(com.oracle.svm.core.reflect.RuntimeMetadataDecoder.MetadataAccessor.class, singleton);
        }
    }
}
