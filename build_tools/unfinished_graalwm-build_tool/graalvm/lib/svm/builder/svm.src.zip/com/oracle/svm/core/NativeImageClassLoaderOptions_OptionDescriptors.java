// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: NativeImageClassLoaderOptions.java
package com.oracle.svm.core;

import java.util.*;
import jdk.graal.compiler.options.*;
import jdk.graal.compiler.options.OptionType;
import jdk.graal.compiler.options.OptionStability;

public class NativeImageClassLoaderOptions_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "AddExports": {
            return OptionDescriptor.create(
                /*name*/ "AddExports",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ com.oracle.svm.core.option.AccumulatingLocatableMultiOptionValue.Strings.class,
                /*help*/ "Value <module>/<package>=<target-module>(,<target-module>)* updates <module> to export <package> to <target-module>, regardless of module declaration. <target-module> can be ALL-UNNAMED to export to all unnamed modules.",
                /*declaringClass*/ NativeImageClassLoaderOptions.class,
                /*fieldName*/ "AddExports",
                /*option*/ NativeImageClassLoaderOptions.AddExports,
                /*stability*/ OptionStability.EXPERIMENTAL,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "AddOpens": {
            return OptionDescriptor.create(
                /*name*/ "AddOpens",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ com.oracle.svm.core.option.AccumulatingLocatableMultiOptionValue.Strings.class,
                /*help*/ "Value <module>/<package>=<target-module>(,<target-module>)* updates <module> to open <package> to <target-module>, regardless of module declaration.",
                /*declaringClass*/ NativeImageClassLoaderOptions.class,
                /*fieldName*/ "AddOpens",
                /*option*/ NativeImageClassLoaderOptions.AddOpens,
                /*stability*/ OptionStability.EXPERIMENTAL,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "AddReads": {
            return OptionDescriptor.create(
                /*name*/ "AddReads",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ com.oracle.svm.core.option.AccumulatingLocatableMultiOptionValue.Strings.class,
                /*help*/ "Value <module>=<target-module>(,<target-module>)* updates <module> to read <target-module>, regardless of module declaration. <target-module> can be ALL-UNNAMED to read all unnamed modules.",
                /*declaringClass*/ NativeImageClassLoaderOptions.class,
                /*fieldName*/ "AddReads",
                /*option*/ NativeImageClassLoaderOptions.AddReads,
                /*stability*/ OptionStability.EXPERIMENTAL,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "EnableNativeAccess": {
            return OptionDescriptor.create(
                /*name*/ "EnableNativeAccess",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ com.oracle.svm.core.option.AccumulatingLocatableMultiOptionValue.Strings.class,
                /*help*/ "A comma-separated list of modules that are permitted to perform restricted native operations. The module name can also be ALL-UNNAMED.",
                /*declaringClass*/ NativeImageClassLoaderOptions.class,
                /*fieldName*/ "EnableNativeAccess",
                /*option*/ NativeImageClassLoaderOptions.EnableNativeAccess,
                /*stability*/ OptionStability.EXPERIMENTAL,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "ListModules": {
            return OptionDescriptor.create(
                /*name*/ "ListModules",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "List observable modules and exit.",
                /*declaringClass*/ NativeImageClassLoaderOptions.class,
                /*fieldName*/ "ListModules",
                /*option*/ NativeImageClassLoaderOptions.ListModules,
                /*stability*/ OptionStability.EXPERIMENTAL,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 5;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("AddExports");
                    case 1: return get("AddOpens");
                    case 2: return get("AddReads");
                    case 3: return get("EnableNativeAccess");
                    case 4: return get("ListModules");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
