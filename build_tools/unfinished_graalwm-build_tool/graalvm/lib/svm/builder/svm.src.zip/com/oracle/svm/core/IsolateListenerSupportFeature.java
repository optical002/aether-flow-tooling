// CheckStyle: stop header check
// CheckStyle: stop line length check
package com.oracle.svm.core;

// GENERATED CONTENT - DO NOT EDIT
// Annotated type: com.oracle.svm.core.IsolateListenerSupport
// Annotation: com.oracle.svm.core.feature.AutomaticallyRegisteredImageSingleton
// Annotation processor: com.oracle.svm.processor.AutomaticallyRegisteredImageSingletonProcessor

import org.graalvm.nativeimage.ImageSingletons;
import com.oracle.svm.core.feature.AutomaticallyRegisteredFeature;

@AutomaticallyRegisteredFeature
public class IsolateListenerSupportFeature implements com.oracle.svm.core.feature.InternalFeature, com.oracle.svm.core.layeredimagesingleton.FeatureSingleton, com.oracle.svm.core.layeredimagesingleton.UnsavedSingleton {
    @Override
    public void afterRegistration(AfterRegistrationAccess access) {
        if (ImageSingletons.lookup(com.oracle.svm.core.layeredimagesingleton.LoadedLayeredImageSingletonInfo.class).handledDuringLoading(com.oracle.svm.core.IsolateListenerSupport.class)){
            return;
        }
        var singleton = new com.oracle.svm.core.IsolateListenerSupport();
        ImageSingletons.add(com.oracle.svm.core.IsolateListenerSupport.class, singleton);
    }
}
