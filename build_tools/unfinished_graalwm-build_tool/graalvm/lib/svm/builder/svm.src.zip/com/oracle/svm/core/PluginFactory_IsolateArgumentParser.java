// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: jdk.graal.compiler.replacements.processor.ReplacementsAnnotationProcessor, jdk.graal.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core;


import java.lang.annotation.Annotation;
import jdk.graal.compiler.core.common.type.Stamp;
import jdk.graal.compiler.graph.NodeInputList;
import jdk.graal.compiler.nodes.ConstantNode;
import jdk.graal.compiler.nodes.PluginReplacementNode;
import jdk.graal.compiler.nodes.ValueNode;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedFoldInvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import jdk.graal.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugins;
import jdk.graal.compiler.nodes.spi.Replacements;
import jdk.graal.compiler.options.ExcludeFromJacocoGeneratedReport;
import jdk.vm.ci.meta.JavaConstant;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;

//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getOptionCount()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_IsolateArgumentParser_getOptionCount extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_IsolateArgumentParser_getOptionCount.FUNCTION);
            return true;
        }
        int result = com.oracle.svm.core.IsolateArgumentParser.getOptionCount();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_IsolateArgumentParser_getOptionCount() {
        super("getOptionCount");
    }
}
//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getOptionCount()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_IsolateArgumentParser_getOptionCount implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_IsolateArgumentParser_getOptionCount();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        int result = com.oracle.svm.core.IsolateArgumentParser.getOptionCount();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getOptionIndex(com.oracle.svm.core.option.RuntimeOptionKey<?>)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_IsolateArgumentParser_getOptionIndex extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_IsolateArgumentParser_getOptionIndex.FUNCTION);
            return true;
        }
        @SuppressWarnings({"rawtypes"})
        com.oracle.svm.core.option.RuntimeOptionKey arg0;
        if (args[0].isConstant()) {
            arg0 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(com.oracle.svm.core.option.RuntimeOptionKey.class, args[0].asJavaConstant());
            assert arg0 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_IsolateArgumentParser_getOptionIndex.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        int result = com.oracle.svm.core.IsolateArgumentParser.getOptionIndex(arg0);
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_IsolateArgumentParser_getOptionIndex(GeneratedPluginInjectionProvider injection) {
        super("getOptionIndex", com.oracle.svm.core.option.RuntimeOptionKey.class);
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getOptionIndex(com.oracle.svm.core.option.RuntimeOptionKey<?>)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_IsolateArgumentParser_getOptionIndex implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_IsolateArgumentParser_getOptionIndex();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        @SuppressWarnings({"rawtypes"})
        com.oracle.svm.core.option.RuntimeOptionKey arg0;
        if (args.get(0).isConstant()) {
            arg0 = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(com.oracle.svm.core.option.RuntimeOptionKey.class, args.get(0).asJavaConstant());
            assert arg0 != null;
        } else {
            return false;
        }
        int result = com.oracle.svm.core.IsolateArgumentParser.getOptionIndex(arg0);
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getOptions()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_IsolateArgumentParser_getOptions extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_IsolateArgumentParser_getOptions.FUNCTION);
            return true;
        }
        @SuppressWarnings({"rawtypes"})
        com.oracle.svm.core.option.RuntimeOptionKey[] result = com.oracle.svm.core.IsolateArgumentParser.getOptions();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_IsolateArgumentParser_getOptions(GeneratedPluginInjectionProvider injection) {
        super("getOptions");
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getOptions()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_IsolateArgumentParser_getOptions implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_IsolateArgumentParser_getOptions();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        @SuppressWarnings({"rawtypes"})
        com.oracle.svm.core.option.RuntimeOptionKey[] result = com.oracle.svm.core.IsolateArgumentParser.getOptions();
        JavaConstant constant = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getOptions0()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_IsolateArgumentParser_getOptions0 extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_IsolateArgumentParser_getOptions0.FUNCTION);
            return true;
        }
        com.oracle.svm.core.IsolateArgumentParser arg0;
        if (args[0].isConstant()) {
            arg0 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(com.oracle.svm.core.IsolateArgumentParser.class, args[0].asJavaConstant());
            assert arg0 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_IsolateArgumentParser_getOptions0.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        com.oracle.svm.core.option.RuntimeOptionKey[] result = arg0.getOptions0();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_IsolateArgumentParser_getOptions0(GeneratedPluginInjectionProvider injection) {
        super("getOptions0", InvocationPlugin.Receiver.class);
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getOptions0()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_IsolateArgumentParser_getOptions0 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_IsolateArgumentParser_getOptions0();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        com.oracle.svm.core.IsolateArgumentParser arg0;
        if (args.get(0).isConstant()) {
            arg0 = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(com.oracle.svm.core.IsolateArgumentParser.class, args.get(0).asJavaConstant());
            assert arg0 != null;
        } else {
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        com.oracle.svm.core.option.RuntimeOptionKey[] result = arg0.getOptions0();
        JavaConstant constant = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getParsedArgsSize()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_IsolateArgumentParser_getParsedArgsSize extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_IsolateArgumentParser_getParsedArgsSize.FUNCTION);
            return true;
        }
        int result = com.oracle.svm.core.IsolateArgumentParser.getParsedArgsSize();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    Plugin_IsolateArgumentParser_getParsedArgsSize() {
        super("getParsedArgsSize");
    }
}
//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getParsedArgsSize()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_IsolateArgumentParser_getParsedArgsSize implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_IsolateArgumentParser_getParsedArgsSize();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        int result = com.oracle.svm.core.IsolateArgumentParser.getParsedArgsSize();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: singleton()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_IsolateArgumentParser_singleton extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_IsolateArgumentParser_singleton.FUNCTION);
            return true;
        }
        com.oracle.svm.core.IsolateArgumentParser result = com.oracle.svm.core.IsolateArgumentParser.singleton();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_IsolateArgumentParser_singleton(GeneratedPluginInjectionProvider injection) {
        super("singleton");
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: singleton()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_IsolateArgumentParser_singleton implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_IsolateArgumentParser_singleton();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        com.oracle.svm.core.IsolateArgumentParser result = com.oracle.svm.core.IsolateArgumentParser.singleton();
        JavaConstant constant = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

public class PluginFactory_IsolateArgumentParser implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.IsolateArgumentParser.class, new Plugin_IsolateArgumentParser_getOptionCount());
        plugins.register(com.oracle.svm.core.IsolateArgumentParser.class, new Plugin_IsolateArgumentParser_getOptionIndex(injection));
        plugins.register(com.oracle.svm.core.IsolateArgumentParser.class, new Plugin_IsolateArgumentParser_getOptions(injection));
        plugins.register(com.oracle.svm.core.IsolateArgumentParser.class, new Plugin_IsolateArgumentParser_getOptions0(injection));
        plugins.register(com.oracle.svm.core.IsolateArgumentParser.class, new Plugin_IsolateArgumentParser_getParsedArgsSize());
        plugins.register(com.oracle.svm.core.IsolateArgumentParser.class, new Plugin_IsolateArgumentParser_singleton(injection));
    }
}
