// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: jdk.graal.compiler.replacements.processor.ReplacementsAnnotationProcessor, jdk.graal.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.genscavenge;


import java.lang.annotation.Annotation;
import jdk.graal.compiler.core.common.type.Stamp;
import jdk.graal.compiler.graph.NodeInputList;
import jdk.graal.compiler.nodes.ConstantNode;
import jdk.graal.compiler.nodes.PluginReplacementNode;
import jdk.graal.compiler.nodes.ValueNode;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedFoldInvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import jdk.graal.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugins;
import jdk.graal.compiler.nodes.spi.Replacements;
import jdk.graal.compiler.options.ExcludeFromJacocoGeneratedReport;
import jdk.vm.ci.meta.JavaConstant;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;

//        class: com.oracle.svm.core.genscavenge.AlignedHeapChunk
//       method: getObjectsStartOffset()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_AlignedHeapChunk_getObjectsStartOffset extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_AlignedHeapChunk_getObjectsStartOffset.FUNCTION);
            return true;
        }
        org.graalvm.word.UnsignedWord result = com.oracle.svm.core.genscavenge.AlignedHeapChunk.getObjectsStartOffset();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_AlignedHeapChunk_getObjectsStartOffset(GeneratedPluginInjectionProvider injection) {
        super("getObjectsStartOffset");
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.genscavenge.AlignedHeapChunk
//       method: getObjectsStartOffset()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_AlignedHeapChunk_getObjectsStartOffset implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_AlignedHeapChunk_getObjectsStartOffset();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.word.UnsignedWord result = com.oracle.svm.core.genscavenge.AlignedHeapChunk.getObjectsStartOffset();
        JavaConstant constant = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.genscavenge.AlignedHeapChunk
//       method: getUsableSizeForObjects()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_AlignedHeapChunk_getUsableSizeForObjects extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_AlignedHeapChunk_getUsableSizeForObjects.FUNCTION);
            return true;
        }
        org.graalvm.word.UnsignedWord result = com.oracle.svm.core.genscavenge.AlignedHeapChunk.getUsableSizeForObjects();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.api.replacements.Fold.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_AlignedHeapChunk_getUsableSizeForObjects(GeneratedPluginInjectionProvider injection) {
        super("getUsableSizeForObjects");
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.genscavenge.AlignedHeapChunk
//       method: getUsableSizeForObjects()
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_AlignedHeapChunk_getUsableSizeForObjects implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_AlignedHeapChunk_getUsableSizeForObjects();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.word.UnsignedWord result = com.oracle.svm.core.genscavenge.AlignedHeapChunk.getUsableSizeForObjects();
        JavaConstant constant = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

public class PluginFactory_AlignedHeapChunk implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.genscavenge.AlignedHeapChunk.class, new Plugin_AlignedHeapChunk_getObjectsStartOffset(injection));
        plugins.register(com.oracle.svm.core.genscavenge.AlignedHeapChunk.class, new Plugin_AlignedHeapChunk_getUsableSizeForObjects(injection));
    }
}
