// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: RuntimeAssertionsSupport.java
package com.oracle.svm.core;

import java.util.*;
import jdk.graal.compiler.options.*;
import jdk.graal.compiler.options.OptionType;
import jdk.graal.compiler.options.OptionStability;

public class RuntimeAssertionsSupport_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "RuntimeAssertions": {
            return OptionDescriptor.create(
                /*name*/ "RuntimeAssertions",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ com.oracle.svm.core.option.AccumulatingLocatableMultiOptionValue.Strings.class,
                /*help*/ "Enable or disable Java assert statements at run time",
                /*declaringClass*/ RuntimeAssertionsSupport.Options.class,
                /*fieldName*/ "RuntimeAssertions",
                /*option*/ RuntimeAssertionsSupport.Options.RuntimeAssertions,
                /*stability*/ OptionStability.EXPERIMENTAL,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "RuntimeSystemAssertions": {
            return OptionDescriptor.create(
                /*name*/ "RuntimeSystemAssertions",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Enable or disable Java system assertions at run time",
                /*declaringClass*/ RuntimeAssertionsSupport.Options.class,
                /*fieldName*/ "RuntimeSystemAssertions",
                /*option*/ RuntimeAssertionsSupport.Options.RuntimeSystemAssertions,
                /*stability*/ OptionStability.EXPERIMENTAL,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 2;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("RuntimeAssertions");
                    case 1: return get("RuntimeSystemAssertions");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
