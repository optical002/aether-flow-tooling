// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: jdk.graal.compiler.replacements.processor.ReplacementsAnnotationProcessor, jdk.graal.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.cpufeature;


import java.lang.annotation.Annotation;
import jdk.graal.compiler.core.common.type.Stamp;
import jdk.graal.compiler.debug.GraalError;
import jdk.graal.compiler.graph.NodeInputList;
import jdk.graal.compiler.nodes.PluginReplacementNode;
import jdk.graal.compiler.nodes.ValueNode;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import jdk.graal.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugins;
import jdk.graal.compiler.nodes.spi.Replacements;
import jdk.graal.compiler.options.ExcludeFromJacocoGeneratedReport;
import jdk.vm.ci.meta.ResolvedJavaMethod;

//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck
//       method: <T>isSupported(java.lang.Enum<T>)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_RuntimeCPUFeatureCheck_isSupported__0 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg0;
        if (args[0].isConstant()) {
            arg0 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args[0].asJavaConstant());
            assert arg0 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__0.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        if (com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.intrinsify(b, arg0)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__0.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_RuntimeCPUFeatureCheck_isSupported__0(GeneratedPluginInjectionProvider injection) {
        super("isSupported", java.lang.Enum.class);
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck
//       method: <T>isSupported(java.lang.Enum<T>)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__0 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__0();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg0;
        if (args.get(0).isConstant()) {
            arg0 = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args.get(0).asJavaConstant());
            assert arg0 != null;
        } else {
            return false;
        }
        if (com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.intrinsify(b, arg0)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck
//       method: <T>isSupported(java.lang.Enum<T>,java.lang.Enum<T>)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_RuntimeCPUFeatureCheck_isSupported__1 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg0;
        if (args[0].isConstant()) {
            arg0 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args[0].asJavaConstant());
            assert arg0 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__1.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg1;
        if (args[1].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args[1].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__1.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[1];
            return false;
        }
        if (com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.intrinsify(b, arg0, arg1)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__1.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_RuntimeCPUFeatureCheck_isSupported__1(GeneratedPluginInjectionProvider injection) {
        super("isSupported", java.lang.Enum.class, java.lang.Enum.class);
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck
//       method: <T>isSupported(java.lang.Enum<T>,java.lang.Enum<T>)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__1 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__1();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg0;
        if (args.get(0).isConstant()) {
            arg0 = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args.get(0).asJavaConstant());
            assert arg0 != null;
        } else {
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg1;
        if (args.get(1).isConstant()) {
            arg1 = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args.get(1).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        if (com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.intrinsify(b, arg0, arg1)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck
//       method: <T>isSupported(java.lang.Enum<T>,java.lang.Enum<T>,java.lang.Enum<T>)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_RuntimeCPUFeatureCheck_isSupported__2 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg0;
        if (args[0].isConstant()) {
            arg0 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args[0].asJavaConstant());
            assert arg0 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__2.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg1;
        if (args[1].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args[1].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__2.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[1];
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg2;
        if (args[2].isConstant()) {
            arg2 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args[2].asJavaConstant());
            assert arg2 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__2.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[2];
            return false;
        }
        if (com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__2.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final jdk.graal.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_RuntimeCPUFeatureCheck_isSupported__2(GeneratedPluginInjectionProvider injection) {
        super("isSupported", java.lang.Enum.class, java.lang.Enum.class, java.lang.Enum.class);
        this.snippetReflection = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck
//       method: <T>isSupported(java.lang.Enum<T>,java.lang.Enum<T>,java.lang.Enum<T>)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__2 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__2();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg0;
        if (args.get(0).isConstant()) {
            arg0 = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args.get(0).asJavaConstant());
            assert arg0 != null;
        } else {
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg1;
        if (args.get(1).isConstant()) {
            arg1 = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args.get(1).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg2;
        if (args.get(2).isConstant()) {
            arg2 = injection.getInjectedArgument(jdk.graal.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args.get(2).asJavaConstant());
            assert arg2 != null;
        } else {
            return false;
        }
        if (com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

public class PluginFactory_RuntimeCPUFeatureCheck implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck.class, new Plugin_RuntimeCPUFeatureCheck_isSupported__0(injection));
        plugins.register(com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck.class, new Plugin_RuntimeCPUFeatureCheck_isSupported__1(injection));
        plugins.register(com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck.class, new Plugin_RuntimeCPUFeatureCheck_isSupported__2(injection));
    }
}
