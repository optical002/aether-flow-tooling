// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: jdk.graal.compiler.replacements.processor.ReplacementsAnnotationProcessor, jdk.graal.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.genscavenge.graal.nodes;


import java.lang.annotation.Annotation;
import jdk.graal.compiler.core.common.type.Stamp;
import jdk.graal.compiler.graph.NodeInputList;
import jdk.graal.compiler.nodes.PluginReplacementNode;
import jdk.graal.compiler.nodes.ValueNode;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import jdk.graal.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugins;
import jdk.graal.compiler.nodes.spi.Replacements;
import jdk.graal.compiler.options.ExcludeFromJacocoGeneratedReport;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;

//        class: com.oracle.svm.core.genscavenge.graal.nodes.FormatPodNode
//       method: formatPod(org.graalvm.word.Pointer,java.lang.Class<?>,int,byte[],boolean,boolean,jdk.graal.compiler.replacements.AllocationSnippets.FillContent,boolean)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_FormatPodNode_formatPod extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        ValueNode arg1 = args[1];
        ValueNode arg2 = args[2];
        ValueNode arg3 = args[3];
        ValueNode arg4 = args[4];
        ValueNode arg5 = args[5];
        ValueNode arg6 = args[6];
        boolean arg7;
        if (args[7].isConstant()) {
            arg7 = args[7].asJavaConstant().asInt() != 0;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_FormatPodNode_formatPod.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[7];
            return false;
        }
        com.oracle.svm.core.genscavenge.graal.nodes.FormatPodNode node = new com.oracle.svm.core.genscavenge.graal.nodes.FormatPodNode(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
        b.addPush(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_FormatPodNode_formatPod() {
        super("formatPod", org.graalvm.word.Pointer.class, java.lang.Class.class, int.class, byte[].class, boolean.class, boolean.class, jdk.graal.compiler.replacements.AllocationSnippets.FillContent.class, boolean.class);
    }
}
//        class: com.oracle.svm.core.genscavenge.graal.nodes.FormatPodNode
//       method: formatPod(org.graalvm.word.Pointer,java.lang.Class<?>,int,byte[],boolean,boolean,jdk.graal.compiler.replacements.AllocationSnippets.FillContent,boolean)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_FormatPodNode_formatPod implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_FormatPodNode_formatPod();

    @Override
    public boolean replace(GraphBuilderContext b, Replacements injection, Stamp stamp, NodeInputList<ValueNode> args) {
        ValueNode arg0 = args.get(0);
        ValueNode arg1 = args.get(1);
        ValueNode arg2 = args.get(2);
        ValueNode arg3 = args.get(3);
        ValueNode arg4 = args.get(4);
        ValueNode arg5 = args.get(5);
        ValueNode arg6 = args.get(6);
        boolean arg7;
        if (args.get(7).isConstant()) {
            arg7 = args.get(7).asJavaConstant().asInt() != 0;
        } else {
            return false;
        }
        com.oracle.svm.core.genscavenge.graal.nodes.FormatPodNode node = new com.oracle.svm.core.genscavenge.graal.nodes.FormatPodNode(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
        b.addPush(JavaKind.Object, node);
        return true;
    }
}

public class PluginFactory_FormatPodNode implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.genscavenge.graal.nodes.FormatPodNode.class, new Plugin_FormatPodNode_formatPod());
    }
}
