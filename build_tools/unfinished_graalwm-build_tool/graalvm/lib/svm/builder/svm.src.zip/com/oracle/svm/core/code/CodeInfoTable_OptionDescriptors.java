// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: CodeInfoTable.java
package com.oracle.svm.core.code;

import java.util.*;
import jdk.graal.compiler.options.*;
import jdk.graal.compiler.options.OptionType;
import jdk.graal.compiler.options.OptionStability;

public class CodeInfoTable_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "CodeCacheCounters": {
            return OptionDescriptor.create(
                /*name*/ "CodeCacheCounters",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Count accesses to the image and runtime code info table",
                /*declaringClass*/ CodeInfoTable.Options.class,
                /*fieldName*/ "CodeCacheCounters",
                /*option*/ CodeInfoTable.Options.CodeCacheCounters,
                /*stability*/ OptionStability.EXPERIMENTAL,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 1;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("CodeCacheCounters");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
