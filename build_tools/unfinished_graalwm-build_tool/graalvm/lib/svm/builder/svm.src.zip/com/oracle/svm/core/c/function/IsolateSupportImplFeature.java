// CheckStyle: stop header check
// CheckStyle: stop line length check
package com.oracle.svm.core.c.function;

// GENERATED CONTENT - DO NOT EDIT
// Annotated type: com.oracle.svm.core.c.function.IsolateSupportImpl
// Annotation: com.oracle.svm.core.feature.AutomaticallyRegisteredImageSingleton
// Annotation processor: com.oracle.svm.processor.AutomaticallyRegisteredImageSingletonProcessor

import org.graalvm.nativeimage.ImageSingletons;
import com.oracle.svm.core.feature.AutomaticallyRegisteredFeature;

@AutomaticallyRegisteredFeature
public class IsolateSupportImplFeature implements com.oracle.svm.core.feature.InternalFeature, com.oracle.svm.core.layeredimagesingleton.FeatureSingleton, com.oracle.svm.core.layeredimagesingleton.UnsavedSingleton {
    @Override
    public void afterRegistration(AfterRegistrationAccess access) {
        boolean match = false;
        match = match || !ImageSingletons.lookup(com.oracle.svm.core.layeredimagesingleton.LoadedLayeredImageSingletonInfo.class).handledDuringLoading(org.graalvm.nativeimage.impl.IsolateSupport.class);
        if (!match) { return; }
        var singleton = new com.oracle.svm.core.c.function.IsolateSupportImpl();
        if (!ImageSingletons.lookup(com.oracle.svm.core.layeredimagesingleton.LoadedLayeredImageSingletonInfo.class).handledDuringLoading(org.graalvm.nativeimage.impl.IsolateSupport.class)){
            ImageSingletons.add(org.graalvm.nativeimage.impl.IsolateSupport.class, singleton);
        }
    }
}
