// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: jdk.graal.compiler.replacements.processor.ReplacementsAnnotationProcessor, jdk.graal.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core;


import java.lang.annotation.Annotation;
import jdk.graal.compiler.nodes.ValueNode;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import jdk.graal.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import jdk.graal.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugin;
import jdk.graal.compiler.nodes.graphbuilderconf.InvocationPlugins;
import jdk.vm.ci.meta.ResolvedJavaMethod;

//        class: com.oracle.svm.core.SubstrateUtil
//       method: breakpoint(java.lang.Object)
// generated-by: jdk.graal.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_SubstrateUtil_breakpoint extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        jdk.graal.compiler.nodes.BreakpointNode node = new jdk.graal.compiler.nodes.BreakpointNode(arg0);
        b.add(node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return jdk.graal.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_SubstrateUtil_breakpoint() {
        super("breakpoint", java.lang.Object.class);
    }
}

public class PluginFactory_SubstrateUtil implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.SubstrateUtil.class, new Plugin_SubstrateUtil_breakpoint());
    }
}
